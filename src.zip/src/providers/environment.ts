export const environment = {
    production: false,
    pusher: {
      key: 'f1088e34ed17896f3b69',
      cluster: 'ap1'
    }
  };