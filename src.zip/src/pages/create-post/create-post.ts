import { Component, ViewChild  } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';
// import { HomePage } from '../home/home';
import { NewsfeedPage } from '../newsfeed/newsfeed';
import {Http, Headers, RequestOptions}  from "@angular/http";
import { LoadingController } from 'ionic-angular';
import 'rxjs/add/operator/map';


@Component({
  
  selector: 'page-create-post',
  
  templateUrl: 'create-post.html'
  
  })
  
  export class CreatePostPage {
  info:any;

  @ViewChild("item") item;
  
  @ViewChild("description") description;
  
  @ViewChild("price") price;

  @ViewChild("image") image;

  
  constructor(public navCtrl: NavController, public alertCtrl: AlertController,  private http: Http,  public loading: LoadingController) {
    const data = JSON.parse(localStorage.getItem('server_response'));
    this.info = data.server_response;
  }
  
  Post(){
  
  //// check to confirm the username, email, telephone and password fields are filled
  
  if(this.item.value=="" ){
  
  let alert = this.alertCtrl.create({
  
  title:"ATTENTION",
  
  subTitle:"Item field is empty",
  
  buttons: ['OK']
  
  });
  
  alert.present();
  
  } else
  
  if(this.description.value==""){
  
  let alert = this.alertCtrl.create({
  
  title:"ATTENTION",
  
  subTitle:"Description field is empty",
  
  buttons: ['OK']
  
  });
  
  alert.present();
  
  }
  
  else
  
  if(this.price.value=="" ){
  
  let alert = this.alertCtrl.create({
  
  title:"ATTENTION",
  
  subTitle:"Price field is empty",
  
  buttons: ['OK']
  
  });
  
  alert.present();
  
  } 
  
  else
  
  if(this.image.value=="" ){
  
  let alert = this.alertCtrl.create({
  
  title:"ATTENTION",
  
  subTitle:"Image field is empty",
  
  buttons: ['OK']
  
  });
  
  alert.present();
  
  } 
  

  else
  
  {
  
  var headers = new Headers();
  
  headers.append("Accept", 'application/json');
  
  headers.append('Content-Type', 'application/json' );
  
  let options = new RequestOptions({ headers: headers });
  
  let data = {
  
  item: this.item.value,
  description: this.description.value,
  image: this.image.value,
  price: this.price.value,
  user_id_fk: this.info[0].id
  
  };
  
  let loader = this.loading.create({
  
  content: 'Processing please wait…',
  
  });
  
  loader.present().then(() => {
  
  this.http.post('http://localhost/ewearit/api/createpost.php',data, options)
  
  .map(res => res.json())
  
  .subscribe(res => {
  
  loader.dismiss()
  
  if(res=="Added successfuly"){
  
    let alert = this.alertCtrl.create({
    
    title:"CONGRATS",
    
    subTitle:(res),
    
    buttons: ['OK']
    
    });
    
    alert.present();
    
    this.navCtrl.setRoot(NewsfeedPage);
  
  }
  else {
  
    let alert = this.alertCtrl.create({
    
    title:"ERROR",
    
    subTitle:(res),
    
    buttons: ['OK']
    
    });
    
    alert.present();
  
  }
  
  });
  
  });
  
  }
  
  }
}