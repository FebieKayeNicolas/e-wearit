import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { ProfilePage } from '../profile/profile';
import {Http, Headers, RequestOptions}  from "@angular/http";
import { LoadingController } from 'ionic-angular';
import 'rxjs/add/operator/map';

@Component({
  selector: 'page-edit-profile',
  templateUrl: 'edit-profile.html'
})
export class EditProfilePage {

  items:any;
  username: any;
  firstname: any;
  lastname: any;
  email: any;
  mobile: any;
  password: any;
  oldUsernameValue: any;
  oldFirstnameValue: any;
  oldLastnameValue: any;
  oldEmailValue: any;
  oldMobileValue: any;
  oldPasswordValue: any;
  @ViewChild("newUsername") newUsername;
  @ViewChild("newFirstname") newFirstname;
  @ViewChild("newLastname") newLastname;
  @ViewChild("newEmail") newEmail;
  @ViewChild("newMobile") newMobile;
  @ViewChild("newPassword") newPassword;

  constructor(public navCtrl: NavController, private http: Http, public loading: LoadingController, public params: NavParams, public alertCtrl: AlertController) {
  }


  ionViewDidLoad(){
    
            this.getfeed();
          }
          
        
          getfeed(){
            var headers = new Headers();
            headers.append("Accept", 'application/json');
            headers.append('Content-Type', 'application/json' );
            let options = new RequestOptions({ headers: headers });
               
             let loader = this.loading.create({
                content: 'Processing please wait...',
              });
            
             loader.present().then(() => {
            
            this.http.post('http://localhost/ewearit/api/edit_profile.php',options)
            .map(res => res.json())
            .subscribe(res => {
            
             loader.dismiss()
            this.items=res.server_response;
            
            console.log(this.items);
            });
            });
          }
        
          ngOnInit(){   
                this.username = this.params.get('username') ;
                this.firstname = this.params.get('firstname') ;
                this.lastname = this.params.get('lastname') ;
                this.email = this.params.get('email') ;          
                this.mobile = this.params.get('mobile') ;
                this.password = this.params.get('password') ;   
                this.oldUsernameValue = this.params.get('username') ;
                this.oldFirstnameValue = this.params.get('firstname') ;
                this.oldLastnameValue = this.params.get('lastname') ;
                this.oldEmailValue = this.params.get('email') ;
                this.oldMobileValue = this.params.get('mobile') ;
                this.oldPasswordValue = this.params.get('password') ;
                
             }
    
  // goToProfile(params){
    // if (!params) params = {};
    // this.navCtrl.push(ProfilePage);
  // }

  Edit(){
    if(this.newUsername.value=="" ){
        let alert = this.alertCtrl.create({
        title:"ATTENTION",
        subTitle:"Username field is empty",
        buttons: ['OK']
      
        });
      
        alert.present();
         } 
    
    else if(this.newFirstname.value==""){
        let alert = this.alertCtrl.create({
        title:"ATTENTION",
        subTitle:"Firstname field is empty",
        buttons: ['OK']
      
        });
      
        alert.present();
      
       } 
       
    else if(this.newLastname.value==""){
         let alert = this.alertCtrl.create({       
         title:"ATTENTION",
         subTitle:" Lastname field is empty",
         buttons: ['OK']
         });
       
         alert.present();
       
        }

    else if(this.newEmail.value==""){
          let alert = this.alertCtrl.create({
          title:"ATTENTION",
          subTitle:"Email field is empty",
          buttons: ['OK']
          });
        
          alert.present();
        
         }

    else if(this.newMobile.value==""){
           let alert = this.alertCtrl.create({
           title:"ATTENTION",
           subTitle:"Mobile field is empty",
           buttons: ['OK']
           });
         
           alert.present();
         
          }

    else if(this.newPassword.value==""){
            let alert = this.alertCtrl.create({
            title:"ATTENTION",
            subTitle:"Password field is empty",
            buttons: ['OK']
            });
          
            alert.present();
          
           }
          
    else{

       var headers = new Headers();
            headers.append("Accept", 'application/json');
            headers.append('Content-Type', 'application/json' );
            let options = new RequestOptions({ headers: headers });
       
          let data = {
                username: this.oldUsernameValue,
                firstname: this.oldFirstnameValue,
                lastname: this.oldLastnameValue,
                email: this.oldEmailValue,
                mobile: this.oldMobileValue,
                password: this.oldPasswordValue,
                newUsername: this.newUsername.value,
                newFirstname: this.newFirstname.value,
                newLastname: this.newLastname.value,
                newEmail: this.newEmail.value,
                newMobile: this.newMobile.value,
                newPassword: this.newPassword.value
              };
       
         let loader = this.loading.create({
            content: 'Processing please wait…',
          });
       
         loader.present().then(() => {
        this.http.post('http://localhost/ionicdon_local/edit_profile.php',data, options)
        .map(res => res.json())
        .subscribe(res => {
         loader.dismiss()
       
        if(res=="Data updated successfully"){
          let alert = this.alertCtrl.create({
            title:"CONGRATS",
            subTitle:(res),
            buttons: ['OK']
            });
       
            alert.present();
         this.navCtrl.push(ProfilePage);
       
        }else
       
        {
       
         let alert = this.alertCtrl.create({
         title:"ERROR",
         subTitle:(res),
         buttons: ['OK']
         });
       
         alert.present();
       
          }
  });
});
       }
      }

  
         }
        
